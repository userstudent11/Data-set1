#!/bin/bash

rm -rf save/logs/*
rm -rf save/checkpoints/*
